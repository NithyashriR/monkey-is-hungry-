var PLAY = 1;
var END = 0;
var gameState = PLAY;

var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score = 0 ;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(500,353);
 
  
 monkey=createSprite(80,320,20,20);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale = 0.1;
  
  ground = createSprite(400,350,900,10);
  ground.velocityX = -7;
  
 FoodGroup =createGroup();
  obstacleGroup = createGroup();
  
  
  
  var survivalTime=0;
 
  
}


function draw() {
   background("lightblue");

   monkey.collide(ground);
  if(gameState === PLAY){
 
    if(keyDown("space")&& monkey.y >= 100) {
        monkey.velocityY = -10;
        }
  monkey.velocityY = monkey.velocityY + 0.6
    
  ground.x = ground.width/2;
  console.log(ground.x);

   spawnbananas();
    spawnobstacles();
 
  stroke("white");
    textSize(20);
    fill("white");
    text("score:"+score,100,100);

  stroke("black");
  textSize(20);
  fill("black");
  survivalTime=Math.ceil(frameCount/frameRate());
  text("survival Time : "+ survivalTime,100,50);
  
  
  if(monkey.isTouching(FoodGroup)){
    FoodGroup.destroyEach();
    score = score+1;
    }
    
      
  if(monkey.isTouching(obstacleGroup)){
     gameState = END;
  }
  }
  
  if(gameState === END){
    
   FoodGroup.lifetime = -1;
    obstacleGroup.lifetime = -1;
    FoodGroup.velocityX =0;
    obstacleGroup.velocityX = 0;
    reset();
  
  
  
  }
  
  drawSprites();
}
function reset(){
  gameState = PLAY;
  survivalTime = 0;
  score = 0;
  obstacleGroup.destroyEach();
  FoodGroup.destroyEach();

}

function spawnbananas(){
  
  if(frameCount%80===0){
    
    banana = createSprite(400,200,20,20);
    banana.addImage(bananaImage);
    banana.scale = 0.1;
    
    banana.velocityX=-7;
    
     
    
    banana.y = Math.round(random(50,340));
    
    banana.lifetime=100;
    
    FoodGroup.add(banana);
    
  }
}

function spawnobstacles(){
  
  if(frameCount%300===0){
    
    stone = createSprite(400,340,20,20);
    stone.addImage(obstaceImage)
    stone.scale = 0.2;
    
    stone.velocityX=-7;
  
    stone.lifetime=100;
    
    obstacleGroup.add(stone);
    
  }
}